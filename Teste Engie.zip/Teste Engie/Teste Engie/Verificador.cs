﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste_Engie
{
    class Verificador
    {
       

        public int validaRoyalFLush(string[] resultJogador)
        {
            int royalS = 0;
            int royalD = 0;
            int royalH = 0;
            int royalC = 0;
            for (int i = 0; i < 5; i++)
            {
                if (Convert.ToBoolean(resultJogador[i].Contains("S")))
                {
                    royalS++;
                }
                if (Convert.ToBoolean(resultJogador[i].Contains("D")))
                {
                    royalD++;
                }
                if (Convert.ToBoolean(resultJogador[i].Contains("H")))
                {
                    royalH++;
                }
                if (Convert.ToBoolean(resultJogador[i].Contains("C")))
                {
                    royalC++;
                }
            }

            string resultRoyal = String.Concat(resultJogador);

            if (resultRoyal.Contains("10") && resultRoyal.Contains("J") && resultRoyal.Contains("Q") && resultRoyal.Contains("K")
                && resultRoyal.Contains("A"))
            {
                if (royalS == 5 || royalD == 5 || royalH == 5 || royalC == 5)
                {                   
                    return 22500000;
                }
                else
                {
                    return 0;
                }
            }
            else
            {
                return 0;
            }
        }

        public int validaStraightFlush(string[] resultJogador)
        {
            int StraightS = 0;
            int StraightD = 0;
            int StraightH = 0;
            int StraightC = 0;
            for (int i = 0; i < 5; i++)
            {
                if (Convert.ToBoolean(resultJogador[i].Contains("S")))
                {
                    StraightS++;
                }
                if (Convert.ToBoolean(resultJogador[i].Contains("D")))
                {
                    StraightD++;
                }
                if (Convert.ToBoolean(resultJogador[i].Contains("H")))
                {
                    StraightH++;
                }
                if (Convert.ToBoolean(resultJogador[i].Contains("C")))
                {
                    StraightC++;
                }
            }
            if (StraightS == 5 || StraightD == 5 || StraightH == 5 || StraightC == 5)
            {
                string[] resultProvisorio = new string[5];
                for (int i = 0; i < 5; i++)
                {
                    resultProvisorio[i] = resultJogador[i];
                    resultProvisorio[i] = resultJogador[i];
                    resultProvisorio[i] = resultProvisorio[i].Replace("S", "").Replace("D", "").Replace("C", "").Replace("H", "");
                    resultProvisorio[i] = resultProvisorio[i].Replace("J", "11").Replace("Q", "12").Replace("K", "13").Replace("A", "14");
                }

                int[] resultFinal = Array.ConvertAll(resultProvisorio, int.Parse);
                Array.Sort(resultFinal, StringComparer.InvariantCulture);

                if (resultFinal[4] == 14 && resultFinal[0] == 2 && resultFinal[1] == 3 && resultFinal[2] == 4 && resultFinal[3] == 5)
                {
                    resultFinal[4] = 1;
                    Array.Sort(resultFinal, StringComparer.InvariantCulture);
                }

                for (int i = 0; i < 1; i++)
                {
                    if ((resultFinal[i]+1) == resultFinal[i+1])
                    {

                        if ((resultFinal[i + 1]+1) == resultFinal[i + 2])
                        {
                            if ((resultFinal[i + 2]+1) == resultFinal[i + 3])
                            {
                                if ((resultFinal[i + 3]+1) == resultFinal[i + 4])
                                {                                
                                    return 1600000 * resultFinal[4];
                                }
                            }
                        }
                    }
                }


            }

            return 0;
        }

        // Validando se o jogador tem uma quadra
        public int validaFourKind(string[] resultJogador)
        {
            string[] resultProvisorio = new string[5];
            for (int i = 0; i < 5; i++)
            {
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultProvisorio[i].Replace("S", "").Replace("D", "").Replace("C", "").Replace("H", "");
                resultProvisorio[i] = resultProvisorio[i].Replace("J", "11").Replace("Q", "12").Replace("K", "13").Replace("A", "14");
            }



            int[] resultFinal = Array.ConvertAll(resultProvisorio, int.Parse);
            Array.Sort(resultFinal, StringComparer.InvariantCulture);

            for (int i = 0; i < 1; i++)
            {
                if (resultFinal[i] == resultFinal[i + 1])
                {
                    if (resultFinal[i + 1] == resultFinal[i + 2])
                    {
                        if (resultFinal[i + 2] == resultFinal[i + 3])
                        {                           
                            return 215000 * resultFinal[3];
                        }
                    }
                }
                else
                {
                    if (resultFinal[i + 4] == resultFinal[i + 3])
                    {
                        if (resultFinal[i + 3] == resultFinal[i + 2])
                        {
                            if (resultFinal[i + 2] == resultFinal[i + 1])
                            {                             
                                return 215000 * resultFinal[3];
                            }
                        }
                    }
                }
            }
            return 0;
        }

        public int validaFullHouse(string[] resultJogador)
        {
            string[] resultProvisorio = new string[5];
            for (int i = 0; i < 5; i++)
            {
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultProvisorio[i].Replace("S", "").Replace("D", "").Replace("C", "").Replace("H", "");
                resultProvisorio[i] = resultProvisorio[i].Replace("J", "11").Replace("Q", "12").Replace("K", "13").Replace("A", "14");
            }


            int[] resultFinal = Array.ConvertAll(resultProvisorio, int.Parse);
            Array.Sort(resultFinal, StringComparer.InvariantCulture);

            for (int i = 0; i < 1; i++)
            {
                if (resultFinal[i] == resultFinal[i + 1] && resultFinal[i + 1] == resultFinal[i + 2])
                {
                    if (resultFinal[i + 4] == resultFinal[i + 3])
                    {                        
                        return 30200 * resultFinal[1];
                    }
                }
                else
                {
                    if (resultFinal[i + 4] == resultFinal[i + 3] && resultFinal[i + 3] == resultFinal[i + 2])
                    {
                        if (resultFinal[i] == resultFinal[i + 1])
                        {                                                        
                            return 30200 * resultFinal[3];
                        }
                    }
                }
            }
            return 0;
        }

        public int validaFlush(string[] resultJogador)
        {
            int flushS = 0, flushH = 0, flushC = 0, flushD = 0;

            //verificando Flush
            for (int i = 0; i < 5; i++)
            {
                if (Convert.ToBoolean(resultJogador[i].Contains("C")))
                {
                    flushC++;
                }
                if (Convert.ToBoolean(resultJogador[i].Contains("D")))
                {
                    flushD++;
                }
                if (Convert.ToBoolean(resultJogador[i].Contains("H")))
                {
                    flushH++;
                }
                if (Convert.ToBoolean(resultJogador[i].Contains("S")))
                {
                    flushS++;
                }
            }
            if (flushD == 5 || flushC == 5 || flushH == 5 || flushS == 5)
            {
                return 60300;
            }

            return 0;
        }

        public int validaStraight(string[] resultJogador)
        {
            string[] resultProvisorio = new string[5];
            for (int i = 0; i < 5; i++)
            {
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultProvisorio[i].Replace("S", "").Replace("D", "").Replace("C", "").Replace("H", "");
                resultProvisorio[i] = resultProvisorio[i].Replace("J", "11").Replace("Q", "12").Replace("K", "13").Replace("A", "14");
            }

            int[] resultFinal = Array.ConvertAll(resultProvisorio, int.Parse);
            Array.Sort(resultFinal, StringComparer.InvariantCulture);

            if (resultFinal[4] == 14 && resultFinal[0] == 2 && resultFinal[1] == 3 && resultFinal[2] == 4 && resultFinal[3] == 5)
            {
                resultFinal[4] = 1;
                Array.Sort(resultFinal, StringComparer.InvariantCulture);
            }

            for (int i = 0; i < 1; i++)
            {
                if ((resultFinal[i] + 1) == resultFinal[i + 1])
                {

                    if ((resultFinal[i + 1] + 1) == resultFinal[i + 2])
                    {
                        if ((resultFinal[i + 2] + 1) == resultFinal[i + 3])
                        {
                            if ((resultFinal[i + 3] + 1) == resultFinal[i + 4])
                            {
                                return 4300 * resultFinal[4];
                            }
                        }
                    }
                }
            }
            return 0;
        }

        // Validando se o jogador tem uma trinca
        public int validaThreeKind(string[] resultJogador)
        {
            string[] resultProvisorio = new string[5];
            for (int i = 0; i < 5; i++)
            {
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultProvisorio[i].Replace("S", "").Replace("D", "").Replace("C", "").Replace("H", "");
                resultProvisorio[i] = resultProvisorio[i].Replace("J", "11").Replace("Q", "12").Replace("K", "13").Replace("A", "14");
            }



            int[] resultFinal = Array.ConvertAll(resultProvisorio, int.Parse);
            Array.Sort(resultFinal, StringComparer.InvariantCulture);

            for (int i = 0; i < 1; i++)
            {
                if (resultFinal[i] == resultFinal[i + 1])
                {
                    if (resultFinal[i + 1] == resultFinal[i + 2])
                    {
                        return 600 * resultFinal[1];
                    }
                }
                else if (resultFinal[i + 1] == resultFinal[i + 2])
                {
                    if (resultFinal[i + 2] == resultFinal[i + 3])
                    {
                        return 600 * resultFinal[2];
                    }
                }
                else
                {
                    if (resultFinal[i + 4] == resultFinal[i + 3])
                    {
                        if (resultFinal[i + 3] == resultFinal[i + 2])
                        {
                            return 600 * resultFinal[3];
                        }
                    }
                }
            }
            return 0;
        }

        // Validando se o jogador tem dois pares
        public int validaTwoPair(string[] resultJogador)
        {
            string[] resultProvisorio = new string[5];
            for (int i = 0; i < 5; i++)
            {
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultProvisorio[i].Replace("S", "").Replace("D", "").Replace("C", "").Replace("H", "");
                resultProvisorio[i] = resultProvisorio[i].Replace("J", "11").Replace("Q", "12").Replace("K", "13").Replace("A", "14");
            }



            int[] resultFinal = Array.ConvertAll(resultProvisorio, int.Parse);
            Array.Sort(resultFinal, StringComparer.InvariantCulture);

            for (int i = 0; i < 1; i++)
            {
                if (resultFinal[i] == resultFinal[i + 1] && resultFinal[i + 2] == resultFinal[i + 3])
                {
                    return 80 * resultFinal[3];
                }
                else if (resultFinal[i + 1] == resultFinal[i + 2] && resultFinal[i + 3] == resultFinal[i + 4])
                {
                    return 80 * resultFinal[3];
                }
                else if (resultFinal[i] == resultFinal[i + 1] && resultFinal[i + 3] == resultFinal[i + 4])
                {
                    return 80 * resultFinal[3];
                }
                else
                {
                    return 0;
                }
            }
            return 0;
        }

        // Validando se o jogador tem um unico par
        public int validaPair(string[] resultJogador)
        {
            string[] resultProvisorio = new string[5];
            for (int i = 0; i < 5; i++)
            {
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultProvisorio[i].Replace("S", "").Replace("D", "").Replace("C", "").Replace("H", "");
                resultProvisorio[i] = resultProvisorio[i].Replace("J", "11").Replace("Q", "12").Replace("K", "13").Replace("A", "14");
            }



            int[] resultFinal = Array.ConvertAll(resultProvisorio, int.Parse);
            Array.Sort(resultFinal, StringComparer.InvariantCulture);

            for (int i = 0; i < 1; i++)
            {
                if (resultFinal[i] == resultFinal[i + 1] || resultFinal[i] == resultFinal[i + 2] || resultFinal[i] == resultFinal[i + 3] || resultFinal[i] == resultFinal[i + 4])
                {
                    return 10 * resultFinal[0];
                }
                else if (resultFinal[i + 1] == resultFinal[i + 2] || resultFinal[i + 1] == resultFinal[i + 3] || resultFinal[i + 1] == resultFinal[i + 4])
                {
                    return 10 * resultFinal[1];
                }
                else if (resultFinal[i + 2] == resultFinal[i + 3] || resultFinal[i + 2] == resultFinal[i + 4])
                {
                    return 10 * resultFinal[2];
                }
                else if (resultFinal[i + 3] == resultFinal[i + 4])
                {
                    return 10 * resultFinal[3];
                }
                else
                {
                    return 0;
                }
            }
            return 0;
        }

        // Validando a maior carta de um jogador (High Card)
        public int validaHighCard(string[] resultJogador)
        {
            string[] resultProvisorio = new string[5];
            for (int i = 0; i < 5; i++)
            {
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultJogador[i];
                resultProvisorio[i] = resultProvisorio[i].Replace("S", "").Replace("D", "").Replace("C", "").Replace("H", "");
                resultProvisorio[i] = resultProvisorio[i].Replace("J", "11").Replace("Q", "12").Replace("K", "13").Replace("A", "14");
            }

            int[] resultFinal = Array.ConvertAll(resultProvisorio, int.Parse);
            Array.Sort(resultFinal, StringComparer.InvariantCulture);

            return resultFinal[4];
        }

        // Validando empate
        public int validaTie(string[] resultJogadorBlack, string[] resultJogadorWhite)
        {
            string[] resultBlackProvisorio = new string[5];
            for (int i = 0; i < 5; i++)
            {
                resultBlackProvisorio[i] = resultJogadorBlack[i];
                resultBlackProvisorio[i] = resultJogadorBlack[i];
                resultBlackProvisorio[i] = resultBlackProvisorio[i].Replace("S", "").Replace("D", "").Replace("C", "").Replace("H", "");
                resultBlackProvisorio[i] = resultBlackProvisorio[i].Replace("J", "11").Replace("Q", "12").Replace("K", "13").Replace("A", "14");
            }
            string[] resultWhiteProvisorio = new string[5];
            for (int i = 0; i < 5; i++)
            {
                resultWhiteProvisorio[i] = resultJogadorWhite[i];
                resultWhiteProvisorio[i] = resultJogadorWhite[i];
                resultWhiteProvisorio[i] = resultWhiteProvisorio[i].Replace("S", "").Replace("D", "").Replace("C", "").Replace("H", "");
                resultWhiteProvisorio[i] = resultWhiteProvisorio[i].Replace("J", "11").Replace("Q", "12").Replace("K", "13").Replace("A", "14");
            }

            int[] resultTieBlack = Array.ConvertAll(resultBlackProvisorio, int.Parse);
            int[] resultTieWhite = Array.ConvertAll(resultWhiteProvisorio, int.Parse);
            Array.Sort(resultTieBlack, StringComparer.InvariantCulture);
            Array.Sort(resultTieWhite, StringComparer.InvariantCulture);

            
            //Verificar vencedor ou empate
            if (resultTieBlack[3] > resultTieWhite[3])
            {
                return 2;
            }
            else if (resultTieBlack[3] < resultTieWhite[3])
            {
                return 1;
            }
            else if (resultTieBlack[2] > resultTieWhite[2])
            {
                return 2;
            }
            else if (resultTieBlack[2] < resultTieWhite[2])
            {
                return 1;
            }
            else if (resultTieBlack[1] > resultTieWhite[1])
            {
                return 2;
            }
            else if (resultTieBlack[1] < resultTieWhite[1])
            {
                return 1;
            }
            else if (resultTieBlack[0] > resultTieWhite[0])
            {
                return 2;
            }
            else if (resultTieBlack[0] < resultTieWhite[0])
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

    }
}