﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste_Engie
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite as 10 cartas do jogo:");

            string cartasDoJogo;
            cartasDoJogo = Console.ReadLine();

            //Console.WriteLine(cartasDoJogo);

            string[] carta = new string[10];
            carta = cartasDoJogo.Split(' ');

            // Usado para guardar as cartas dos jogadores, sendo as 5 primeiras posições as cartas do jogador Black, e as outras 5
            // sendo as cartas do jogador White
            string[] cartasJogadorBlack = new string[5];
            string[] cartasJogadorWhite = new string[5];

            //FOR para separar as cartas dos jogadores Black/White
            for (int i = 0; i < 10; i++)
            {
                if (i < 5)
                {
                    cartasJogadorBlack[i] = carta[i];
                }
                if (i > 4)
                {
                    cartasJogadorWhite[i - 5] = carta[i];
                }
            }

            // BLACK                            
            Verificador compareRoyalFlush = new Verificador();
            int ResultadoBlack = compareRoyalFlush.validaRoyalFLush(cartasJogadorBlack);
            int ResultadoWhite = compareRoyalFlush.validaRoyalFLush(cartasJogadorWhite);
            if (ResultadoBlack == 0)
            {
                Verificador compareStraightFlush = new Verificador();
                ResultadoBlack = compareStraightFlush.validaStraightFlush(cartasJogadorBlack);
                if (ResultadoBlack == 0)
                {
                    Verificador compareFourKind = new Verificador();
                    ResultadoBlack = compareFourKind.validaFourKind(cartasJogadorBlack);
                    if (ResultadoBlack == 0)
                    {
                        Verificador compareFullHouse = new Verificador();
                        ResultadoBlack = compareFullHouse.validaFullHouse(cartasJogadorBlack);
                        if (ResultadoBlack == 0)
                        {
                            Verificador compareFlush = new Verificador();
                            ResultadoBlack = compareFlush.validaFlush(cartasJogadorBlack);
                            if (ResultadoBlack == 0)
                            {
                                Verificador compareStraight = new Verificador();
                                ResultadoBlack = compareStraight.validaStraight(cartasJogadorBlack);
                                if (ResultadoBlack == 0)
                                {
                                    Verificador compareThreeKind = new Verificador();
                                    ResultadoBlack = compareThreeKind.validaThreeKind(cartasJogadorBlack);
                                    if (ResultadoBlack == 0)
                                    {
                                        Verificador compareTwoPair = new Verificador();
                                        ResultadoBlack = compareTwoPair.validaTwoPair(cartasJogadorBlack);
                                        if (ResultadoBlack == 0)
                                        {
                                            Verificador comparePair = new Verificador();
                                            ResultadoBlack = comparePair.validaPair(cartasJogadorBlack);
                                            if (ResultadoBlack == 0)
                                            {
                                                Verificador compareHighCard = new Verificador();
                                                ResultadoBlack = compareHighCard.validaHighCard(cartasJogadorBlack);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // WHITE          
            if (ResultadoWhite == 0)
            {
                Verificador compareStraightFlush = new Verificador();
                ResultadoWhite = compareStraightFlush.validaStraightFlush(cartasJogadorWhite);
                if (ResultadoWhite == 0)
                {
                    Verificador compareFourKind = new Verificador();
                    ResultadoWhite = compareFourKind.validaFourKind(cartasJogadorWhite);
                    if (ResultadoWhite == 0)
                    {
                        Verificador compareFullHouse = new Verificador();
                        ResultadoWhite = compareFullHouse.validaFullHouse(cartasJogadorWhite);
                        if (ResultadoWhite == 0)
                        {
                            Verificador compareFlush = new Verificador();
                            ResultadoWhite = compareFlush.validaFlush(cartasJogadorWhite);
                            if (ResultadoWhite == 0)
                            {
                                Verificador compareStraight = new Verificador();
                                ResultadoWhite = compareStraight.validaStraight(cartasJogadorWhite);
                                if (ResultadoWhite == 0)
                                {
                                    Verificador compareThreeKind = new Verificador();
                                    ResultadoWhite = compareThreeKind.validaThreeKind(cartasJogadorWhite);
                                    if (ResultadoWhite == 0)
                                    {
                                        Verificador compareTwoPair = new Verificador();
                                        ResultadoWhite = compareTwoPair.validaTwoPair(cartasJogadorWhite);
                                        if (ResultadoWhite == 0)
                                        {
                                            Verificador comparePair = new Verificador();
                                            ResultadoWhite = comparePair.validaPair(cartasJogadorWhite);
                                            if (ResultadoWhite == 0)
                                            {
                                                Verificador compareHighCard = new Verificador();
                                                ResultadoWhite = compareHighCard.validaHighCard(cartasJogadorWhite);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            //Mostrar o vencedor ou se deu empate
            if (ResultadoBlack > ResultadoWhite)
            {
                Console.WriteLine("Black wins");
            }
            else if (ResultadoWhite > ResultadoBlack)
            {                
                Console.WriteLine("White wins");               
            }
            else
            {
                Verificador compareTie = new Verificador();
                int ResultadoTie = compareTie.validaTie(cartasJogadorBlack,cartasJogadorWhite);
                if (ResultadoTie == 2)
                {
                    Console.WriteLine("Black Wins");
                }
                else if (ResultadoTie == 1)
                {
                    Console.WriteLine("White Wins");
                }
                else if (ResultadoTie == 0)
                {
                    Console.WriteLine("Tie");
                }
                else 
                {
                    Console.WriteLine("ERROR");
                }
            }

            Console.ReadKey();
        }
    }
}